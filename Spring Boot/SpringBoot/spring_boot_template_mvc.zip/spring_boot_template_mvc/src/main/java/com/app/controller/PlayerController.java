package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.service.PlayerService;

@Controller
@RequestMapping("/player")
public class PlayerController
{
	//dep;PlayerServie
	@Autowired
	private PlayerService playerService;
	//add request handling 
	@PostMapping("/add")
	public String addPlayer(@RequestParam String fn,
			@Requestparam String ln ,
			@RequestParam DateTimeFormat(pattern ="yyyy-mm-dd") LocalDate dob,
			@RequestParam String dob);
}

