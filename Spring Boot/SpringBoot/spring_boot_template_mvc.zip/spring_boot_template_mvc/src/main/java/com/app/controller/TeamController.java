package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.app.service.TeamService;
@Controller
public class TeamController {
	
	@Autowired
	private TeamService tService;
	
	public TeamController() {
		System.out.println("in ctor of "+getClass());
	}
	
	
	@GetMapping("/")
	public String getAllTeamsAbbrivations(Model map)
	{
		System.out.println("in get all teams abbrivations "+map);
		map.addAttribute("teams_abbr",tService.getTeamAbbrivations());
		return "/teams/add_player_form";//AVN : WEB-INF/VIEW /ADD_PLAYER_FORM.JSP
	}
	
	
}
