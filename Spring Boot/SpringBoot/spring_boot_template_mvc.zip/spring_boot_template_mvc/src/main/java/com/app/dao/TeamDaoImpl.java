package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class TeamDaoImpl implements TeamDao {

	@Autowired
	private EntityManager manager;
	@Override
	public List<String> getTeamAbbrivations() {
		String jpql="select t.abbreviation from Team t";
		return manager.createQuery(jpql,String.class).getResultList();
	}

}
