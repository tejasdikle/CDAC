package com.app.service;

public interface PlayerService {
	String addPlayerToTeam()
}
