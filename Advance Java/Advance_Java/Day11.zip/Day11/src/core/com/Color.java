package core.com;

public enum Color 
{
	SILVER(5000) ,RED(3000) ,GREY(6000),BLACK(8000); 
	
	private int additionalCost;
	
	private Color (int additionalCost)
	{
		this.additionalCost = additionalCost;
		
	}
	public int getAdditionalCost(int additionalCost )
	{
		return additionalCost ;
		
	}
	public void setAdditionalCost (int additionalCost )
	{
		this.additionalCost = additionalCost ;
		
	}
	@Override 
	public String toString()
	{
		return name() +"Additional Cost " + additionalCost ;
	}
	
	

}
