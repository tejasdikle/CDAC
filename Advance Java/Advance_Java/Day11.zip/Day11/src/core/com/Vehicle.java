package core.com;

import java.time.LocalDate;

public abstract class Vehicle implements Comparable<Vehicle> 
{
	private String chassino;
	private Color vehicleclr;
	private int basicprice;
	private LocalDate manufacturingDate;
	private String company ;
	private boolean available;
	
	
	


	public Vehicle(String chassino, Color vehicleclr, int basicprice, LocalDate manufacturingDate, String company,
			boolean available) 
	{
		super();
		this.chassino = chassino;
		this.vehicleclr = vehicleclr;
		this.basicprice = basicprice;
		this.manufacturingDate = manufacturingDate;
		this.company = company;
		this.available = available;
	}


	public String getChassino() {
		return chassino;
	}


	public void setChassino(String chassino) {
		this.chassino = chassino;
	}


	public Color getVehicleclr() {
		return vehicleclr;
	}


	public void setVehicleclr(Color vehicleclr) {
		this.vehicleclr = vehicleclr;
	}


	public int getBasicprice() {
		return basicprice;
	}


	public void setBasicprice(int basicprice) {
		this.basicprice = basicprice;
	}


	public LocalDate getManufacturingDate() {
		return manufacturingDate;
	}


	public void setManufacturingDate(LocalDate manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}


	public String getCompany() {
		return company;
	}


	public void setCompany(String company) {
		this.company = company;
	}


	public boolean isAvailable() {
		return available;
	}


	public void setAvailable(boolean available) {
		this.available = available;
	}
	@Override
	public String toString() {
		return "Vehicle [chassino=" + chassino + ", vehicleclr=" + vehicleclr + ", basicprice=" + basicprice
				+ ", manufacturingDate=" + manufacturingDate + ", company=" + company + ", available=" + available
				+ "]";
	}
	
	
	
	
	
	
	
	

}
