package tIteration;

import java.util.ArrayList;
import java.util.Iterator;

public class Test2 
{
	public static void main(String []args)
	{
		ArrayList <String > string = new ArrayList<>();
		String []name = {"tejas","prasad","rahul","nikhil","atharav","mahi"};
		for(String s : name)
			string.add(s);
		Iterator<String> strItr = string.iterator();
		while(strItr.hasNext())
		{
			System.out.println(strItr.next());
			strItr.remove();
		}
		System.out.println("List after remove "+string);
		
		
	}
}
