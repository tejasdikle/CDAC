package tIteration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

public class Test5 {

	public static void main(String[] args) {
		String[] names= {"one","two","three","four","five"};
		ArrayList<String> strings=new ArrayList<>();
		for(String s : names)
			strings.add(s);
		ListIterator<String> stringItr=strings.listIterator(strings.size());
		while(stringItr.hasPrevious())
			System.out.println(stringItr.previous());
	
	}

}
