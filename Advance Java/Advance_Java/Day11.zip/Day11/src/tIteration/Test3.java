package tIteration;

import java.util.ArrayList;
import java.util.Iterator;

public class Test3 
{
	public static void main(String [] args)
	{
		String [] name = {"tejas ","rocky ","mahi","beetu","laksh"};
		ArrayList <String> string = new ArrayList <>();
		for(String s : name )
			string .add(s);
		Iterator<String > Itstr = string.iterator();
		Itstr.remove();
		while(Itstr.hasNext())
		{
			System.out.println(Itstr.next());
			Itstr.remove();
			Itstr.remove();
			
			
		}System.out.println("List after remove : "+string);
	}

}
