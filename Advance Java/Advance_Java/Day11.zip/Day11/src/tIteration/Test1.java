package tIteration;

import java.util.ArrayList;
import java.util.Iterator;

public class Test1 {

	public static void main(String[] args) 
	{
		String[]name = {"A","B","C","D","E","F","G"};
		ArrayList <String> string = new ArrayList<>();
		for(String s : name)
			string.add(s);
		Iterator <String> strItr = string .iterator();
		while(strItr.hasNext())
		{
			System.out.println(strItr.next());
		}
		
		
		
	}

}
