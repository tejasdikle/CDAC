package tIteration;

import java.util.ArrayList;
import java.util.Collections;

public class Test6 
{
	public static void main(String []args)
	{
		ArrayList<String> string = new ArrayList<>();
		String[]name = {"one","two","three","four","five"};
		for(String s: name)
			string.add(s);
		System.out.println(string);
		Collections.sort(string);
		System.out.println(string);
		
	}

}
