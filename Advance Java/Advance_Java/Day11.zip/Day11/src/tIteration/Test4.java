package tIteration;

import java.util.ArrayList;
import java.util.Iterator;

public class Test4 {

	public static void main(String[] args) {
		String[] names= {"one","two","three","four","five"};
		ArrayList<String> string =new ArrayList<>();
		for(String s : names)
			string.add(s);
		
		Iterator<String> stringItr=string.iterator();
		string.set(0, "zero");
		string.remove(0);
		while(stringItr.hasNext()) {
			System.out.println(stringItr.next());			
		}
		System.out.println("list again"+string );//NoSuchElemExc
		

	}

}
