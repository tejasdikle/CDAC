package tester;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import core.com.Vehicle;

public class Showrommanegment 
{
	public static void main(String []args)
	{
		try(Scanner sc = new Scanner(System.in))
		{
			List<Vehicle>vehiclelist = new ArrayList<>();
			boolean exit = false ;
			
			while(!exit)
			{
				System.out.println("Options : 1 . Add a vehicle 2.Display All \n" + "3. Get Specific Vehicle details \n"
						+ "4. Apply discount on specific vehicle \n" + "5. Apply discount on all vehicles by clr \n"
						+ "6. Delete vehicle details by PK \n" + "7. Delete vehicle details by Color\n"
						+ "8. Sort the vehicles as per ch no\n" + "9. Sort the vehicles as per price 0.Exit");
				
				try 
				{
					switch(sc.nextInt())
					{
					case 1:
						System.out.println("Enter vehicle details :  chasisNo,  vehicleClr,  basePrice,  manufactureDate, company");
						Vehicle validateVehicle = valideAllInput(sc.next(),sc.next(),sc.nextInt(),sc.next(),sc.next(),vehiclelist); 
						vehiclelist.add(validateVehicle);
						System.out.println("added vehicle succesfully");
					}
				}catch (Exception e)
				{
					
				}
			}sc.close();
		}
	}

}
