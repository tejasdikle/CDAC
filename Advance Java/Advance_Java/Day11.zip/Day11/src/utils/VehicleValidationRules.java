package utils;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

import core.com.Color;
import core.com.Vehicle;
import custom_exception.VehicleHandlingException;

public class VehicleValidationRules {

	public static void checkForDups(String newChNo, List<Vehicle> vehicles) throws VehicleHandlingException {
		
		Vehicle newVehicle = new Vehicle(newChNo, null, 0, null, newChNo, false); // abc-1248
		if (vehicles.contains(newVehicle))
			throw new VehicleHandlingException("Vehicle can't be added : dup ch no !!!!!!");
		System.out.println("no dups ...");
	}


	public static Color parseAndValidateColor(String color) throws IllegalArgumentException {
		return Color.valueOf(color.toUpperCase());// method throws : IllegalArgumentException , in case of clr out of
													// range
	}


	public static LocalDate parseAndValidateDate(String date) throws DateTimeParseException, VehicleHandlingException {
		// parsing
		LocalDate manuDate = LocalDate.parse(date);
		
		LocalDate checkDate = LocalDate.of(2020, 1, 1);
		if (manuDate.isBefore(checkDate))
			throw new VehicleHandlingException("Invalid Manufacture Date!!!!!");
		
		return manuDate;
	}


	public static Vehicle validateAllInputs(String chasisNo, String vehicleClr, int basePrice, String manufactureDate,
			String company, List<Vehicle> showroom)
			throws VehicleHandlingException, IllegalArgumentException, DateTimeParseException 
	{
		// invoke individual validation rules
		checkForDups(chasisNo, showroom);
		Color color = parseAndValidateColor(vehicleClr);
		LocalDate date = parseAndValidateDate(manufactureDate);
		return new Vehicle(chasisNo, color, basePrice, date, company, false);
	}

}
