package custom_exception;

public class VehicleHandlingException extends Exception 
{
	public VehicleHandlingException (String errMesg)
	
	{
		super (errMesg);
	}

}
