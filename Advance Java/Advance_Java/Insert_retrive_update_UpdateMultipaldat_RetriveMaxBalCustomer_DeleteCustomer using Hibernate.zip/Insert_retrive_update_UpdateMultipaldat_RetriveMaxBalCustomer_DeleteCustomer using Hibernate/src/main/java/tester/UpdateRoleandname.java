package tester;
import static utils.HibernateUtils.getSessionFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CustomerDaoImpl;
import pojos.CustRole;
import pojos.Customer;
public class UpdateRoleandname {

	public static void main(String[] args) 
	{
		

		try(SessionFactory sf = getSessionFactory();Scanner sc =new Scanner(System.in))
		{
			System.out.println("Enter the Id New Customer Email and New Name");
		
			CustomerDaoImpl custDao = new CustomerDaoImpl();
			System.out.println(custDao.UpdateRoleAndName(sc.nextInt(), sc.next(), sc.next()));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
