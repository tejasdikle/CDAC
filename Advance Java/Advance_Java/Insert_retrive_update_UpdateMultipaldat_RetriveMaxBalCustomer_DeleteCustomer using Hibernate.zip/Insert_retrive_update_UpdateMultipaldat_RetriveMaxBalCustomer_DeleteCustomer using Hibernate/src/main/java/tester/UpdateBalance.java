package tester;
import static utils.HibernateUtils.getSessionFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CustomerDaoImpl;
import pojos.CustRole;
import pojos.Customer;
public class UpdateBalance {

	public static void main(String[] args) 
	{
		

		try(SessionFactory sf = getSessionFactory();Scanner sc =new Scanner(System.in))
		{
			System.out.println("Enter the Id and new balance ");
		
			CustomerDaoImpl custDao = new CustomerDaoImpl();
			System.out.println(custDao.UpdateBalance(sc.nextInt(),sc.nextInt()));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
