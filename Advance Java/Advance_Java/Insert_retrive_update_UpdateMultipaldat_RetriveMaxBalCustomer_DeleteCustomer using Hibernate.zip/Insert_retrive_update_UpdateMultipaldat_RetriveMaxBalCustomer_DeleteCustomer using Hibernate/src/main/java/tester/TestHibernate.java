package tester;
import org.hibernate.*;
import static utils.HibernateUtils.getSessionFactory;
public class TestHibernate {

	public static void main(String[] args) {
		

		try(SessionFactory sf = getSessionFactory())
		{
			System.out.println("I am in Session Factory "+sf);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
