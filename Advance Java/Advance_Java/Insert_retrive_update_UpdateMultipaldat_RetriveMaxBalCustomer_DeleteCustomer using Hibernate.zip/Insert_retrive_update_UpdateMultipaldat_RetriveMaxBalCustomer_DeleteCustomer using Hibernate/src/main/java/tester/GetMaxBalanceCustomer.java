package tester;
import static utils.HibernateUtils.getSessionFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CustomerDaoImpl;
import pojos.CustRole;
import pojos.Customer;
public class GetMaxBalanceCustomer {

	public static void main(String[] args) 
	{
		

		try(SessionFactory sf = getSessionFactory();Scanner sc =new Scanner(System.in))
		{
			System.out.println("Enter the balance");
		
			CustomerDaoImpl custDao = new CustomerDaoImpl();
			System.out.println(custDao.GetMaxAccountBalance(sc.nextInt()));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
