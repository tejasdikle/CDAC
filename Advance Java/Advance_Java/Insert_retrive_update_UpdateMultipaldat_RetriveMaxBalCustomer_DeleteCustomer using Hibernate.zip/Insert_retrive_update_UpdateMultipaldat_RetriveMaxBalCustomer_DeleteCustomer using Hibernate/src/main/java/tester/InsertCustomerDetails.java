package tester;
import static utils.HibernateUtils.getSessionFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CustomerDaoImpl;
import pojos.CustRole;
import pojos.Customer;
public class InsertCustomerDetails {

	public static void main(String[] args) 
	{
		

		try(SessionFactory sf = getSessionFactory();Scanner sc =new Scanner(System.in))
		{
			CustomerDaoImpl custDao = new CustomerDaoImpl();
			System.out.println("Enter the Customer Details:- Name Email Password Confom_Password CustRole LocalDate(yyyy-mm-dd) Balance");
			Customer cust = new Customer(sc.next(),sc.next(),sc.next(),sc.next(),CustRole.valueOf(sc.next().toUpperCase()),LocalDate.parse(sc.next()),sc.nextInt());
			
			System.out.println(custDao.AddNewCustomer(cust));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
