package tester;
import static utils.HibernateUtils.getSessionFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CustomerDaoImpl;
import pojos.CustRole;
import pojos.Customer;
public class DeleteCustomer {

	public static void main(String[] args) 
	{
		

		try(SessionFactory sf = getSessionFactory();Scanner sc =new Scanner(System.in))
		{
			System.out.println("Enter the Customer Id to delete details");
		
			CustomerDaoImpl custDao = new CustomerDaoImpl();
			System.out.println(custDao.DeleteCustomerDetails(sc.nextInt()));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
