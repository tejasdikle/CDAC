package pojos;

public enum CustRole {
	INDIAN ,FOROINER ,AAFRICAN

}
