package pojos;
import javax.persistence.*;

import pojos.CustRole;

import java.time.LocalDate;
@Entity
@Table(name="Customer_tbl")
public class Customer 
{
	@Id 
	//@GeneratedValue //automatically generated primary key
	@GeneratedValue(strategy=GenerationType.IDENTITY)//auto_increment constraint
	@Column(name="cust_id")
	private Integer custId;
	//@Column(length=20)
	private String name;
	//@Column(length=20,unique = true)//varchar20 unique constraint
	private String email;
	//@Column(length=15,nullable = false) //varchar15
	private String password;
	//@Enumerated(EnumType.STRING)
	//@Column(name ="cust_role",length=20)
	private CustRole custRole;
	//@Transient // no corresponding column
	private String conformPassword;
	//@Column(name="localDate")
	private LocalDate localDate;//column:date
	private int balance;
	
	
	public Customer() //Create default constructor
	{
		System.out.println("Default Constructor Callad");
	}
	
	
	public Customer(String name, String email, String password, String conformPassword, CustRole custRole,
			LocalDate localDate,int balance ) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.conformPassword = conformPassword;
		this.custRole = custRole;
		this.localDate = localDate;
		this.balance = balance;
	}


	public Integer getCustId() {
		return custId;
	}


	public void setCustId(Integer custId) {
		this.custId = custId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getConformPassword() {
		return conformPassword;
	}


	public void setConformPassword(String conformPassword) {
		this.conformPassword = conformPassword;
	}


	public CustRole getCustRole() {
		return custRole;
	}


	public void setCustRole(CustRole custRole) {
		this.custRole = custRole;
	}


	public LocalDate getLocalDate() {
		return localDate;
	}


	public void setLocalDate(LocalDate localDate) {
		this.localDate = localDate;
	}
	


	public int getBalance() {
		return balance;
	}


	public void setBalance(int balance) {
		this.balance = balance;
	}


	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", conformPassword=" + conformPassword + ", custRole=" + custRole + ", localDate=" + localDate + " balance= " + balance+"]";
	}
	
	
	
	
	
	
	

}
