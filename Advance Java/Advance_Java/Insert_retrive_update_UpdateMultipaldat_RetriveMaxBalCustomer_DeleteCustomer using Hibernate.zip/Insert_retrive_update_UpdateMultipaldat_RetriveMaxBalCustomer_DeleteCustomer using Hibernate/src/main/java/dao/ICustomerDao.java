package dao;
import java.util.List;

import pojos.Customer;
public interface ICustomerDao 
{
	String AddNewCustomer(Customer cust);
	Customer GetCustomerDetails(String name);
	String UpdateRoleAndName(int id,String email ,String name);
	String DeleteCustomerDetails(int id);
	List<Customer> GetMaxAccountBalance(int Balance);
	String UpdateBalance(int id ,int balance);
	
	
	

}
