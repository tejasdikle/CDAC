package dao;
import static utils.HibernateUtils.getSessionFactory;

import java.io.Serializable;
import java.util.List;

import org.hibernate.*;

import pojos.Customer;


public class CustomerDaoImpl implements ICustomerDao 
{
	//there is no data member no ctor no cleanup
	

	@Override
	public String AddNewCustomer(Customer cust) 
	{
		String mesg ="Customer register failed";
		Session session = getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		try
		{
			Serializable custId = session.save(cust);
			tx.commit();
			mesg ="Customer register succsefully "+custId;
		}
		catch(Exception e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
			
		}finally 
		{
			if (session != null)
				session.close();
		}
		return mesg;
	}
	@Override
	public Customer GetCustomerDetails(String name) 
	{
		Customer ctm=null;
		Session session = getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		String jpql = "select c from Customer c where c.name = :name";
		try
		{
			ctm =session.createQuery(jpql,Customer.class).setParameter("name", name).getSingleResult();
			
			tx.commit();
		}catch(Exception e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
				
		}
		
		return ctm;
	}
	@Override
	public String UpdateRoleAndName(int id ,String email, String name) 
	{
		String mesg ="Customer update fail";
		Session session = getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
	
		
		try
		{
			Customer cst=session.get(Customer.class, id);
			cst.setEmail(email);
			cst.setName(name);
			
			tx.commit();
			mesg = "Customer info updated ";
		}catch(Exception e)
		{
			if(tx!= null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}
	@Override
	public List<Customer> GetMaxAccountBalance(int Balance) 
	{
		List<Customer> cst=null;
		Session session = getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		String jpql ="select c from Customer c where c.balance>:balance";
		try
		{
			
			cst=session.createQuery(jpql, Customer.class).setParameter("balance", Balance).getResultList();
			tx.commit();
			
		}catch(Exception e)
		{
			
			if (tx!=null)
				tx.rollback();
			throw e;
		}
		
		return cst;
	}
	@Override
	public String UpdateBalance(int id, int balance) 
	{
		String mesg = "Balance Failed to Update";
		Session session = getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try
		{
			Customer cst = session.get(Customer.class,id);
			cst.setBalance(balance);
			tx.commit();
			mesg = "Balance updated";
		}catch(Exception e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}
	@Override
	public String DeleteCustomerDetails(int id) 
	{
		String mesg = "Customer details fail to delete";
		Customer cst=null;
		Session session = getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		
		try
		{
			cst=session.get(Customer.class, id);
			if(cst!=null)
			{
				session.delete(cst);
				mesg="Customer details Delete succesfully ";
			}
			
			tx.commit();
		}catch(Exception e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		
		return mesg;
	}

	
}
