package dao;

public interface PlayerDao {

}
