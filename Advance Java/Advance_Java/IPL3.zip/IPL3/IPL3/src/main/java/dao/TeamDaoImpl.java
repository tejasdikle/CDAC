package dao;

import static utils.HibernateUtils.getSf;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Team;

public class TeamDaoImpl implements TeamDao {
	

	@Override
	public List<String> getTeamsAbbreviations() {
		// TODO Auto-generated method stub
		List<String> teamAbbr;
		String jpql = "select t.abbreviation from Team t";
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();	
		try {
			teamAbbr=session.createQuery(jpql, String.class).getResultList();
			tx.commit();
		}catch(Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		return teamAbbr;
	}

	@Override
	public Team getTeamDetails(String abbreviation) {
		// TODO Auto-generated method stub
		String jpql="select t from Team t where t.abbreviation=:abbr";
		Team t;
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();	
		try {
			t=session.createQuery(jpql, Team.class).setParameter("abbr", abbreviation).getSingleResult();
			tx.commit();
		}catch(Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		return t;
	}
	
	public List<String> getTeamsByAge(int age){
		List<String> teams;
		String jpql="select t.name from Team t where t.maxAge>:age";
		Team t;
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();	
		try {
			teams = session.createQuery(jpql, String.class).setParameter("age", age).getResultList();
			tx.commit();
		}catch(Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		return teams;
	}
	
	public void updateBattingAvg(int teamId, double minBattingAvg) {
		Team t;
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();	
		try {
			t = session.get(Team.class, teamId);
			t.setMinBattingAvg(minBattingAvg);
			tx.commit();
		}catch(Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
	}
	
	public void changePartUpdateBattingAvg(String teamAbbr, int minWicketsTaken, double minBattingAvg) {
		Team t;
		String jpql="select new pojos.Team(teamId,abbreviation,minBattingAvg,minWicketsTaken) from Team t where t.abbreviation=:abbr";
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();	
		try {
			t = session.createQuery(jpql, Team.class).setParameter("abbr", teamAbbr).getSingleResult();
			t.setMinBattingAvg(minBattingAvg);
			t.setMinWicketsTaken(minWicketsTaken);
			tx.commit();
		}catch(Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
	}
	
	public void updateWicketsTaken(int teamId, int minWicketsTaken) {
		Team t;
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();	
		try {
			t=session.get(Team.class, teamId);
			t.setMinWicketsTaken(minWicketsTaken);
			tx.commit();
		}catch(Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
	}
	
	public void registerTeam(Team team) {
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();	
		try {
			session.save(team);
			tx.commit();
		}catch(Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
	}
	
	
	
}
