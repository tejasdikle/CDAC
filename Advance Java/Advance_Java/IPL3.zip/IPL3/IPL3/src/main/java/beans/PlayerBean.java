package beans;

import java.time.LocalDate;
import java.util.List;

import dao.PlayerDaoImpl;
import dao.TeamDaoImpl;
import pojos.Player;

public class PlayerBean {
	TeamDaoImpl tDao;
	PlayerDaoImpl pDao;
	private String teamAbbr;
	private String firstName;
	private String lastName;
	private String dob;
	private double battingAvg;
	private int wicketsTaken;
	
	public PlayerBean() {
		tDao = new TeamDaoImpl();
		pDao = new PlayerDaoImpl();
	}
	
	
	
	public TeamDaoImpl gettDao() {
		return tDao;
	}



	public void settDao(TeamDaoImpl tDao) {
		this.tDao = tDao;
	}



	public PlayerDaoImpl getpDao() {
		return pDao;
	}



	public void setpDao(PlayerDaoImpl pDao) {
		this.pDao = pDao;
	}



	public String getTeamAbbr() {
		return teamAbbr;
	}



	public void setTeamAbbr(String teamAbbr) {
		this.teamAbbr = teamAbbr;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getDob() {
		return dob;
	}



	public void setDob(String dob) {
		this.dob = dob;
	}



	public double getBattingAvg() {
		return battingAvg;
	}



	public void setBattingAvg(double battingAvg) {
		this.battingAvg = battingAvg;
	}

	public int getWicketsTaken() {
		return wicketsTaken;
	}

	public void setWicketsTaken(int wicketsTaken) {
		this.wicketsTaken = wicketsTaken;
	}

	public List<String> showTeamAbbr(){
		List<String> teamAbbrs;
		teamAbbrs = tDao.getTeamsAbbreviations();
		return teamAbbrs;
	}
	
	public String addPlayer() {
		//String firstName, String lastName, LocalDate dateOfBirth, double battingAverage, Integer wicketsTaken
		Player p = new Player(firstName, lastName, LocalDate.parse(dob), battingAvg, wicketsTaken);
		String mesg = "Player could not be added!!";
		
		pDao.addPlayer(teamAbbr, p);
		mesg="Player added sussessfully!!";
		return mesg;
	} 
}
