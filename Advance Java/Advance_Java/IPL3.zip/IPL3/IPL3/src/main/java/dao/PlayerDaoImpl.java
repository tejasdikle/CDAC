package dao;

import static utils.HibernateUtils.getSf;

import org.hibernate.*;

import pojos.Player;
import pojos.Team;

public class PlayerDaoImpl implements PlayerDao {
	
	public void addPlayer(String teamAbbr, Player player) {
		Team team;
		String teamQuery = "select t from Team t where t.abbreviation=:abbr";
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();	
		try {
			team = session.createQuery(teamQuery, Team.class).setParameter("abbr", teamAbbr).getSingleResult(); 
			team.addPlayer(player);
			session.save(player);
			tx.commit();
		}catch(Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
		}
	}
	
	
}
