package pojos;

import java.time.LocalDate;

import javax.persistence.*;

@Entity
@Table(name ="players")
public class Player {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int playerId;
	@Column(name = "first_name", length = 30)
	private String firstName;
	@Column(name = "last_name", length = 30)
	private String lastName;
	@Column(name = "dob")
	private LocalDate dateOfBirth;
	@Column(name = "batting_avg" , precision = 2)
	private double battingAverage;
	@ManyToOne()
	@JoinColumn(name="team_id")
	private Team team;
	@Column(name = "wickets_taken")
	private Integer wicketsTaken;
	
	
	public Player() {}
	
	public Player(String firstName, String lastName, LocalDate dateOfBirth, double battingAverage, Integer wicketsTaken) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.battingAverage = battingAverage;
		this.wicketsTaken = wicketsTaken;
	}

	public Team getTeam() {
		return team;
	}
	
	public void setTeam(Team team) {
		this.team = team;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public double getBattingAverage() {
		return battingAverage;
	}
	public void setBattingAverage(double battingAverage) {
		this.battingAverage = battingAverage;
	}
	public Integer getWicketsTaken() {
		return wicketsTaken;
	}
	public void setWicketsTaken(Integer wicketsTaken) {
		this.wicketsTaken = wicketsTaken;
	}
	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	@Override
	public String toString() {
		return "Player [firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth
				+ ", battingAverage=" + battingAverage + ", wicketsTaken=" + wicketsTaken + "]";
	}
	
	
	
}
