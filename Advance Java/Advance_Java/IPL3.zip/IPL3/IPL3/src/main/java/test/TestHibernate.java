package test;

import static utils.HibernateUtils.getSf;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.PlayerDaoImpl;
import dao.TeamDaoImpl;
import pojos.Player;
import pojos.Team;

public class TestHibernate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TeamDaoImpl tDao = new TeamDaoImpl();
		PlayerDaoImpl pDao = new PlayerDaoImpl(); 
		try(SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in);){
			/*for(int i = 0; i < 4; i++) {
				System.out.println("Enter team details:/nTeam Name, Abbreviation, Owner, maxAge, minBattingAvg, minWicketsTaken");
				Team team = new Team(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextInt(), sc.nextDouble(), sc.nextInt());
				sc.nextLine();
				tDao.registerTeam(team);
			}
			System.out.println("Enter abbr for team to get details:");
			Team t = tDao.getTeamDetails(sc.nextLine());
			System.out.println("Team details: " + t);*/
			System.out.println("Enter player team abbr: ");
			String teamAbbr = sc.nextLine();
			System.out.println("Add Player: /nfirstName, lastName, dOB, battingAverage, wicketsTaken");
			Player player = new Player(sc.nextLine(),sc.nextLine(),LocalDate.parse(sc.next()), sc.nextDouble(), sc.nextInt());
			pDao.addPlayer(teamAbbr, player);
			/*System.out.println("Enter player age for team to get details:");
			List<String> teams = tDao.getTeamsByAge(sc.nextInt());
			System.out.println("Teams where player can be added is: " + teams);*/
			/*System.out.println("enter team Id and new batting average");
			tDao.updateBattingAvg(sc.nextInt(), sc.nextDouble());*/
			/*System.out.println("enter team Id and Wickets taken");
			tDao.updateWicketsTaken(sc.nextInt(), sc.nextInt());*/
			/*System.out.println("enter team abbr, batting avg and Wickets taken");
			tDao.changePartUpdateBattingAvg(sc.next(), sc.nextInt(), sc.nextDouble());*/
		}catch(RuntimeException e) {
			e.printStackTrace();
		}
	}

}
