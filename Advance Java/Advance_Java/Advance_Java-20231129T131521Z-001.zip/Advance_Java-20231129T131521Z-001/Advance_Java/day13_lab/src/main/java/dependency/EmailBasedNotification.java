package dependency;

public class EmailBasedNotification implements CustomerNotificationService{

	public EmailBasedNotification() {
		System.out.println("in cnstr of " +getClass().getName());
	}
	@Override
	public void alertCustomer(String email) {
		System.out.println("Alerttt!!! " + email +" using email ");
		
	}

}
