package tester;
import static utils.HibernateUtils.getFactory;

import java.util.List;

import org.hibernate.SessionFactory;

import beans.PlayerBean;
import dao.TeamDaoImpl;

public class TestHibernate {

	public static void main(String[] args) {
		try(SessionFactory sf=getFactory()) {
			TeamDaoImpl tDao = new TeamDaoImpl();
			PlayerBean p = new PlayerBean(); 
			System.out.println("hib up n running....");
			
			System.out.println("Using tDao");
			List<String> list = tDao.getTeamsAbbreviations();
			list.forEach(i->System.out.println(i+" "));
			System.out.println("Using bean");
			List<String> list1 = p.showTeamAbbr();
			list1.forEach(i->System.out.println(i+" "));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
