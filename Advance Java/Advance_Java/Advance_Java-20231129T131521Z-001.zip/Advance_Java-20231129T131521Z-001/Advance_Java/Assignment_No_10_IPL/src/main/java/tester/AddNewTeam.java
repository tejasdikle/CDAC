package tester;

import static utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;


import dao.TeamDao;
import dao.TeamDaoImpl;
import pojos.Team;

public class AddNewTeam {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in); SessionFactory sf = getFactory()) {
			TeamDao dao = new TeamDaoImpl();
			//String name, String abbreviation,String owner, int maxAge, double minBattingAvg,
			//int minWicketsTaken
			System.out.println("Enter new team details : name, abbreviation, owner, maxAge, minBattingAvg,"
					+" minWicketsTaken");
			System.out.println(dao.addNewTeam(new Team(sc.next(), sc.next(),sc.next(),sc.nextInt(),
					sc.nextDouble(),sc.nextInt())));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
