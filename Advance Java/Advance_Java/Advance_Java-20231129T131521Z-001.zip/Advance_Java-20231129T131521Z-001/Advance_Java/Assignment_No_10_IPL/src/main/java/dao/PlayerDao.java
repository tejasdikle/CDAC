package dao;

import java.sql.SQLException;

import pojos.Player;

public interface PlayerDao {
//add a method to add new player to the team
	String savePlayerDetails(Player player, Long teamId) ;
	String addPlayerDetails(String teamAbbr, Player player);
}
