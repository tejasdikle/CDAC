package tester;

public class AddNewPlayerDetails {

}
