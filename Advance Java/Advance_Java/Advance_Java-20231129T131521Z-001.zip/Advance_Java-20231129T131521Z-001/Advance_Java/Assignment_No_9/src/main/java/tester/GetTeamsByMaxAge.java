package tester;

import org.hibernate.*;

import dao.TeamDao;
import dao.TeamDaoImpl;
import pojos.Team;

import static utils.HibernateUtils.getFactory;

import java.util.List;
import java.util.Scanner;

public class GetTeamsByMaxAge {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in);
				SessionFactory sf=getFactory()) {
			
			//create dao instance n call method
			TeamDao teamDao=new TeamDaoImpl();
			System.out.println("Enter the age :");
			
			List<Team> team = teamDao.getTeamsByMaxAge(sc.nextInt());
			
			System.out.println("Selected team : ");
			team.forEach(t->System.out.println(t));
			
		} //sf.close() --> DBCP cleaned up ...
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
