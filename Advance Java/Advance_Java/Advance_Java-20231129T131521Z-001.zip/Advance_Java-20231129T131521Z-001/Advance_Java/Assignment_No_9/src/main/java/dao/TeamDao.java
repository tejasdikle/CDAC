package dao;

import java.util.List;

import pojos.Team;

public interface TeamDao {
	//add a method to insert new team details
	String addTeamDetails(Team newTeam);
	
	//add a method to get team details by abbr
	List<Team> getTeamDetails(String abr);
	
	//add a method to find teams which are eligible for specified age
	List<Team> getTeamsByMaxAge(int age);
	//add a method to updater batting avg and wkts taken
	String updateWicketsBattingAvg(Integer id, double batAvg, int wkts);
}
