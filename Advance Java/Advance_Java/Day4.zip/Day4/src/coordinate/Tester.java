package coordinate;

import java.util.*;

import com.cdac.core.Point2D;

public class Tester {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the Array size :");
		Pt[] pts = new Pt[sc.nextInt()];
		// Giving Square bracket because here accepting array element
		
		
		boolean exit = false;
		while (!exit) {
			System.out.println("Enter ur choice :\n1.Insert \n2.Display\n3.Compare\n4.Exits");
			int ch = sc.nextInt();

			switch (ch) {
			case 1: {
				System.out.println("Enter the index where u want to set the points :");
				int index = sc.nextInt();
				if (index <= pts.length && index > 0) {
					if (pts[index] == null) {
						System.out.println("Enter the two Co-ordinate points : ");
						pts[index] = new Pt(sc.nextDouble(), sc.nextDouble());

					} else {
						System.out.println("Points ara already Exited:");
					}
				} else {
					System.out.println("Range out of bound " + (pts.length - 1));
				}

			}
				break;
			case 2: {
				int count = 0;
				for (Pt i : pts) {
					if (pts[count] != null) {
						System.out.println("The point at index " + (count++) + "is" + i.Showdata());

					} else {
						count++;
					}
				}
			}
				break;
			case 3: {
				System.out.println("Enter the two fetch value :");
				int index1 = sc.nextInt();
				int index2 = sc.nextInt();
				if (pts[index1].isEqual(pts[index2])) {
					System.out.println("Both are same ");
				} else {
					System.out.println("Both are not same");
				}
			}
				break;
			case 4: {
				exit = true;
				System.out.println("Program End ");
				break;
			}
			}
		}
		sc.close();
	}
}
