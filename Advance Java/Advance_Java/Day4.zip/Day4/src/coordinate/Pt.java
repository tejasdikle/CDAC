package coordinate;
import java.util.*;
public class Pt 
{
	private double x;
	private double y;
	
	Pt(double x,double y)
	{
		this.x=x;
		this.y=y;
	}
	public String Showdata()
	{
		return "(" + x + " "+ y +")";
	}
	public boolean isEqual(Pt other)
	{
		return this.x == other.x && this.y == other.y;
	}
	double Calculatedistance(Pt other)
	{
		double dx = this.x - other.x;
		double dy = this.y - other.y;
		return Math.sqrt(dx*dx + dy*dy);
	}
}
