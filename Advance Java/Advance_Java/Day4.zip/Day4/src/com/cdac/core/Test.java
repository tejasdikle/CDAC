package com.cdac.core;

import java.util.*;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of array u want :");
		Point2D[] points = new Point2D[sc.nextInt()];

		boolean exit = false;
		while (!exit) {
			System.out.println("Enter ur choice \n 1.Insert\n 2.Display \n 3.Compare \n 4.Exit");
			int ch = sc.nextInt();
			switch (ch) {

			case 1: {
				System.out.println("Enter the index wheree u wnat uplode");
				int index = sc.nextInt();

				if (index <= points.length && index > 0) {
					if (points[index] == null) {
						System.out.println("Enter the co ordinate of the point:");
						points[index] = new Point2D(sc.nextDouble(), sc.nextDouble());

						// System.out.println(points[index].Show());
					} else {
						System.out.println("Point already existed:");
					}
				} else {
					System.out.println("The index are out of bound :" + (points.length - 1));
				}
			}

				break;

			case 2: {
				int count = 0;
				for (Point2D i : points) {
					if (points[count] != null) {
						System.out.println("The point at index " + (count++) + "is" + i.Show());

					} else {
						count++;
					}

				}

			}
				break;
			case 3: {
				System.out.println("Insert the 2 fetch points from :");
				int index1 = sc.nextInt();
				int index2 = sc.nextInt();

				if (points[index1].isEqual(points[index2])) {
					System.out.println("Point are equal:");
					System.out.println("Distance between zero:");
				} else {
					System.out.println("point are not equal");
					System.out.println("Distance between teo two point are :" + points[index1].Calculatedistance(points[index2]));
				}
			}
				break;

			case 4: {
				exit = true;
				System.out.println("Program end :");
				break;
			}
			default: {
				System.out.println("Kindly enter ur choice again :");

			}
			}

		}
		sc.close();

	}

}
