package com.cdac.core;

public class Point2D 
{
	private double x;
	private double y;
	
	Point2D(double x,double y)
	{
		this.x =x;
		this.y =y;
		
	}
	public String Show() 
	{
		return "(" + x + ", " + y + ")";
	}
	public boolean isEqual(Point2D other)
	{
		return this.x==other.x && this.y==other.y;
	}
	public  double Calculatedistance(Point2D other)
	{
		double num1 = this.x - other.x;
		double num2 = this.y - other.y;
		return Math.sqrt(num1*num1 + num2*num2);
	}

	

}
