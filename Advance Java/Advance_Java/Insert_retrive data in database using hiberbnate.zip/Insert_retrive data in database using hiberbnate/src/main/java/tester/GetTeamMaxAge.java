package tester;

import org.hibernate.*;

import dao.ITeamDao;
import dao.TeamDaoImpl;
import pojos.Team;

import static utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class GetTeamMaxAge {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in);
			SessionFactory sf=getFactory()) {
			System.out.println("hibernate booted successfully ! "+sf);
			//create dao instance n call method
			ITeamDao dao=new TeamDaoImpl();
	
			System.out.println("please eneter age ");
			System.out.println(dao.getTeamWithMaximumAge(sc.nextInt()));
			
			
		} //sf.close() --> DBCP cleaned up ...
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
