package dao;

import java.util.List;

import pojos.Team;

public interface ITeamDao {
//add a method to insert new team details
	String addTeamDetails(Team newTeam);
	Team getTeamDetails(String abbrivation);
	List<Team> getTeamWithMaximumAge(int Age);
	String updateAvgAndWickets(int id ,double avg,int wickets);
}
