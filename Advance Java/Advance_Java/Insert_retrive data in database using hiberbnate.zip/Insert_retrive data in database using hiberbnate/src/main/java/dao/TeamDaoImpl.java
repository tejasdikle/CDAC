package dao;

import pojos.Team;
import org.hibernate.*;


import static utils.HibernateUtils.getFactory;

import java.util.List;

public class TeamDaoImpl implements ITeamDao {

	@Override
	public String addTeamDetails(Team newTeam) {
		// 1. open hibernate session from SF
		
		Session session = getFactory().getCurrentSession(); //get session.save
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		
		
		
		try {
			session.save(newTeam);
			
			//end of try => success
			tx.commit();
		} catch (RuntimeException e) {
			// rollback tx n re throw the exc to the caller
			if (tx != null)
				tx.rollback();
			throw e;
		} 
		return "Added new Team with ID "+newTeam.getTeamId();
	}

	@Override
	public Team getTeamDetails(String abbrivation) {
		Team team=null;
		Session session = getFactory().getCurrentSession(); //get session.save
		Transaction tx = session.beginTransaction();
		String jpql ="select p from Team p where p.abbreviation = :abbriv";
		
		
		try {
			//end of try => success
			team=session.createQuery(jpql, Team.class).setParameter("abbriv", abbrivation).getSingleResult();
			tx.commit();
		} catch (RuntimeException e) {
			// rollback tx n re throw the exc to the caller
			if (tx != null)
				tx.rollback();
			throw e;
		} 
		
		return team;
	}

	@Override
	public List<Team> getTeamWithMaximumAge(int age) {
		List<Team> teams=null;
		Session session = getFactory().getCurrentSession(); //get session.save
		Transaction tx = session.beginTransaction();
		String jpql ="select t from Team t where t.maxAge>:age";
		try {
			//end of try => success
			teams=session.createQuery(jpql, Team.class).setParameter("age", age).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			// rollback tx n re throw the exc to the caller
			if (tx != null)
				tx.rollback();
			throw e;
		} 
		
		return teams;
	}

	@Override
	public String updateAvgAndWickets(int id, double avg, int wickets) {
	// 1. open hibernate session from SF
		
		Session session = getFactory().getCurrentSession(); //get session.save
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
	String msg="update failed ";
		
		
		try {
			Team team=session.get(Team.class, id);
			team.setMinBattingAvg(avg);
			team.setMinWicketsTaken(wickets);
			
			//end of try => success
			tx.commit();
		msg="update done";
		} catch (RuntimeException e) {
			// rollback tx n re throw the exc to the caller
			if (tx != null)
				tx.rollback();
			throw e;
		} 
		return msg;
	}

}


