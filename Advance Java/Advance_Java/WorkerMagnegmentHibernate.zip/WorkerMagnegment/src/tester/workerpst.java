package tester;

import static utils.WorkerInfo.fetchDBConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class workerpst {

	public static void main(String[] args) {
		String sqlquery = "select id,name,salary,join_date from worker where deptid=? and id between ? and ?";
						
		try(Scanner sc = new Scanner(System.in);
			Connection cn = fetchDBConnection();
			PreparedStatement pst = cn.prepareStatement(sqlquery);
			)
		{
			System.out.println("Enter deptid and begin id n end id to fetch details:");
			//System.out.println("Enter deptid and begin date n end Date to fetch details:");
			pst.setString(1,sc.next());
			pst.setInt(2, sc.nextInt());
			pst.setInt(3, sc.nextInt());
			//for date 
//			pst.setDate(2, Date.valueOf(sc.next()));
//			pst.setDate(3,Date.valueOf(sc.next()));
			try(ResultSet rst = pst.executeQuery())
			{
				while(rst.next())
					System.out.printf("Id %d Name %s Salary %.1f Join_Date %s%n",rst.getInt(1),rst.getString(2),rst.getDouble(3),rst.getString(4));
				
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
