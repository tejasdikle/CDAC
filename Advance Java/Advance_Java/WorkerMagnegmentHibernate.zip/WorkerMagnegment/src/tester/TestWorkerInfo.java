package tester;

import java.sql.*;
import static utils.WorkerInfo.fetchDBConnection;

public class TestWorkerInfo 
{

	public static void main(String[] args) 
	{
		try(Connection cn = fetchDBConnection();
				//create empty statement () from connection
				//throw exception 
				Statement st = cn.createStatement();
				//execute query or write query 
				ResultSet rst = st.executeQuery("select * from worker");)
		{
		while(rst.next())
				System.out.printf("Worker_ID=>%d Name=>%s Salary=>%.1f Join_Date=>%s%n",rst.getInt(1),rst.getString(2),rst.getDouble(3),rst.getString(4));
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
