package dao;
import org.hibernate.*;


import static utils.HibernateUtils.getsessionFactory;

import java.util.List;


import pojos.Team;

public class TeamDaoImpl implements ITeamDao {

	@Override
	public String addNewTeam(Team newTeam) 
	{
		String mesg ="Team Added fail !!! Try again";
		Session session = getsessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		try
		{
			session.persist(newTeam);
			tx.commit();
			mesg = "New Team Added Successfully ";
		}catch(Exception e)
		{
			if(tx!=null)
				tx.rollback();
			throw e;
				
		}
		
		return mesg;
	}

	

	
}
