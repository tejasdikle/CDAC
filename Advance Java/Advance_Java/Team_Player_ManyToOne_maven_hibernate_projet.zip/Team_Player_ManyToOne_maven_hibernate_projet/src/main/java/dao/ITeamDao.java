package dao;


import java.util.List;

import pojos.Team;

public interface ITeamDao 
{
	String addNewTeam(Team newTeam);
	
	



}
