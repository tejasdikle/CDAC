package dao;

import org.hibernate.*;
import static utils.HibernateUtils.getsessionFactory;
import pojos.Players;
import pojos.Team;

public class PlayerDaoImpl implements IPlayerDao {

	@Override
	public String addPlayerDetails(Players player, int teamId) {
		Session session = getsessionFactory().getCurrentSession();
		Transaction tx =  session.beginTransaction();
		try
		{
			Team team = session.get(Team.class, teamId);
			
			if(team != null)
			{
				team.addPlayer(player);
				session.persist(player);
			}
			tx.commit();
		}catch (Exception e)
		{
			if(tx != null )
				tx.rollback();
			throw e;
		}
		return "Player added Successfully";
	}

}
