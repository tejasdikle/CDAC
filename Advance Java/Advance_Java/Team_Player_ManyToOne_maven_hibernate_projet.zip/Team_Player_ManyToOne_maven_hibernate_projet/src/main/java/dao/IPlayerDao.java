package dao;

import pojos.Players;

public interface IPlayerDao 
{
	String addPlayerDetails(Players player , int teamId);

}
