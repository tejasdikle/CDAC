package test;

import static utils.HibernateUtils.getsessionFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.PlayerDaoImpl;

import pojos.PlayerType;
import pojos.Players;

public class AddPlayer {

	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in);SessionFactory sf = getsessionFactory())
		{
			PlayerDaoImpl playerDao = new PlayerDaoImpl();
			System.out.println("Enter First_Name Last_Name Date_Of_Birth Player_Type Age MinBattingAvg ");
			Players player = new Players(sc.next(),sc.next(),LocalDate.parse(sc.next()),PlayerType.valueOf(sc.next().toUpperCase()),sc.nextInt(),sc.nextInt());
			System.out.println("Enter Team id");
			System.out.println(playerDao.addPlayerDetails(player,sc.nextInt()));
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
