package pojos;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;



@Entity
@Table(name="Team_tbl")
public class Team extends BaseEntity      //extends from base entity
{
	@Column(name = "team_name", length = 10)
	private String teamName;
	
	@Column(name="location", length=10)
	private String Location;
	//for player 
	//add the association property
	//Team 1--->*Player
	@OneToMany(mappedBy = "myTeam") //if we don't use mappedBy extra table will be create in db
	private List<Players> player =new ArrayList<>();
	
	public Team() 
	{
		System.out.println("Default constructor called");
	}

	public Team(String teamName, String location) {
		super();
		this.teamName = teamName;
		Location = location;
		
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public List<Players> getList() {
		return player;
	}

	public void setList(List<Players> player) {
		this.player = player;
	}

	@Override
	public String toString() {
		return "Team [teamName=" + teamName + ", Location=" + Location +  "]";
	}
	public void addPlayer(Players p) {
		player.add(p);
		p.setMyTeam(this);

	}
	public void removePlayer(Players p) {
		player.add(p);
		p.setMyTeam(null);
	}

	
	

}
