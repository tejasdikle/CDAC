package pojos;
import java.time.LocalDate;

import javax.persistence.*;
//one,parent,inverse
@Entity
@Table(name="IPL")
public class Players extends BaseEntity
{
	@Column(name="first_name",length=20)
	private String firstName;
	@Column(name="last_name",length=20)
	private String lastName;
	@Column(name = "local_date",length = 10)
	private LocalDate dob;
	@Enumerated(EnumType.STRING)
	@Column(name ="player_type" ,length =15)
	private PlayerType playerType;
	@Column(length = 2)
	private int age;
	@Column(length=99)
	private int minBattingAvg;
	
	@ManyToOne
	@JoinColumn(name="team_id",nullable=false)
	private Team myTeam;
	//many,child ,owning 
	//Player *--->1Team
	public Players ()
	{
		System.out.println("Default constructor called");
	}

	public Players(String firstName, String lastName, LocalDate dob, PlayerType playerType, int age,int minBattingAvg) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.playerType = playerType;
		this.age = age;
		this.minBattingAvg = minBattingAvg;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public PlayerType getPlayerType() {
		return playerType;
	}

	public void setPlayerType(PlayerType playerType) {
		this.playerType = playerType;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getMinBattingAvg() {
		return minBattingAvg;
	}

	public void setMinBattingAvg(int minBattingAvg) {
		this.minBattingAvg = minBattingAvg;
	}

	public Team getMyTeam() {
		return myTeam;
	}

	public void setMyTeam(Team myTeam) {
		this.myTeam = myTeam;
	}

	@Override
	public String toString() {
		return "Players [firstName=" + firstName + ", lastName=" + lastName + ", dob=" + dob + ", playerType="
				+ playerType + ", age=" + age + ", minBattingAvg=" + minBattingAvg + ", myTeam=" + myTeam + "]";
	}
	
	
	

	
	
}
	