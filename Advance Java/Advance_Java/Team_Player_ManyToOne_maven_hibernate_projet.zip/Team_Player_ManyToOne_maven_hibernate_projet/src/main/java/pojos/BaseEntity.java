package pojos;
import javax.persistence.*;
@MappedSuperclass
public class BaseEntity 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;     //we can use int also 
	@Column(name="id")
	public int getId() {				//getter 
		return id;
	}

	public void setId(int id) {			//setter
		this.id = id;
	}
	
	

}
