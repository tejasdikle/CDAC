package pojos;

public enum PlayerType 
{
	BATSMAN,BOLLER

}
