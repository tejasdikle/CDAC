package lists;

import java.util.ArrayList;

public class IntegerList 
{

	public static void main(String[] args) 
	{
		ArrayList<Integer> list = new ArrayList <>();
		
		System.out.println("Defualt Array list : ");
		for (int i :list )
			System.out.println(i);
			int data[]= {1,2,3,4,5,6,7,8,9,9,23,4,5,6,57};
			for(int i:data)
				System.out.print(i+" ");
			
			
			
		System.out.println("toString "+list);
		
		
		
		System.out.println("tejas Dhikale");
		for(int i =0 ; i<list.size();i++)
		
			System.out.println(list.get(i));
		System.out.println();
		

	}

}
