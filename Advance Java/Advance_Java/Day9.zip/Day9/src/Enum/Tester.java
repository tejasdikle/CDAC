package Enum;

import java.util.Scanner;

public class Tester {

	public static void main(String[] args) 
	{
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("Availbale color in Buket ");
			System.out.println("--------------------------");
			for(Color c : Color.values())
			{
				System.out.println(c +" ");
				
			}
			System.out.println("Chose a color :");
			Color choice = Color.valueOf(sc.next().toUpperCase());
			System.out.println("You chose "+choice );
			System.out.println("--------------------------");
		}
	}

}
