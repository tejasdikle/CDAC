package Enum;

public enum Color 
{
	SILVER ,RED ,PINK ,BLUE ,ORANGE ,BLACK,WHITE ,YELLOW ;
	
	@Override
	public String toString()
	{
		return name().toLowerCase();
	}

}
