package custom_exceptions;

public class SpeedOutOfRangeException extends Exception {
	public SpeedOutOfRangeException (String errmesg) {
	super(errmesg);
	}
}
