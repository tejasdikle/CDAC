package custum_exception;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

import com.Vehicle.Vehicle;

import enums.Color;

public class VehicleValidationRule {
//add a static method to check for dups (PK : ch no)
	public static void checkForDups(String newChNo, List<Vehicle> vehicles) throws VehiclehandlingException {
		
		Vehicle newVehicle = new Vehicle(newChNo); // abc-1248
		if (vehicles.contains(newVehicle))
			throw new VehiclehandlingException("Vehicle can't be added : dup ch no !!!!!!");
		System.out.println("no dups ...");
	}


	public static Color parseAndValidateColor(String color) throws IllegalArgumentException {
		return Color.valueOf(color.toUpperCase());// method throws : IllegalArgumentException , in case of clr out of
													// range
	}

	// add a method for validating : date
	public static LocalDate parseAndValidateDate(String date) throws DateTimeParseException, VehiclehandlingException {
		// parsing
		LocalDate manuDate = LocalDate.parse(date);
	
		LocalDate checkDate = LocalDate.of(2020, 1, 1);
		if (manuDate.isBefore(checkDate))
			throw new VehiclehandlingException("Invalid Manufacture Date!!!!!");
		// => parsing n validation success
		return manuDate;
	}

	public static Vehicle validatpubliceAllInputs(String chasisNo, String vehicleClr, int basePrice, String manufactureDate,String company, List<Vehicle> showroom)
			throws VehiclehandlingException, IllegalArgumentException, DateTimeParseException {
		// invoke individual validation rules

		checkForDups(chasisNo, showroom);
		Color color = parseAndValidateColor(vehicleClr);
		LocalDate date = parseAndValidateDate(manufactureDate);
		return new Vehicle(chasisNo, color, basicprice, manufactureDate, company);
	}

}
