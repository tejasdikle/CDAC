package custum_exception;

public class VehiclehandlingException extends Exception 
{
	public VehiclehandlingException(String errMesg)
	{
	super(errMesg);
	}
}
