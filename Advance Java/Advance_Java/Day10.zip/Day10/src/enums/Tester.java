package enums;

import java.util.Scanner;

public class Tester 
{

	public static void main(String[] args) 
	{
	
		try (Scanner sc = new Scanner(System.in))
		{
			System.out.println("Available color ");
			for(Color c : Color.values())
				System.out.println(c +" ");
			
			System.out.println("Chose your fovourite :");
			Color choice = Color.valueOf(sc.next().toUpperCase());
			System.out.println("Your choice color =>" +choice);
			
			
			choice.setAdditionalCost (choice.getAdditionalCost()+4000);
			System.out.println("Updated Cost :" +choice.getAdditionalCost());
			
				//System.out.println("Additional Cost for per Color ");
				
		}catch (Exception e)
		{
			System.out.println("Incorrect input  ");
		}finally 
		{
			System.out.println("Main Over ");
		}

	}

}
