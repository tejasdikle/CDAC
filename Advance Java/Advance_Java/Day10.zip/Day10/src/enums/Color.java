package enums;

public enum Color 
{
	WHITE(10000) ,RED(5000) ,YELLOW(3000) ,GREEN(600),PINK (500),NANO(5000);
	
	private int additionalCost ;
	
	private Color (int additionalCost )										//CONSTRUCTOR 
	{
		this.additionalCost = additionalCost;
	}
	
	public int getAdditionalCost ()
	{
		return additionalCost;
	}
	
	public void  setAdditionalCost(int additionalCost )         		//PARAMETERISE CONSTRUCTOR 
	{
		this .additionalCost=additionalCost  ;
	}
	@Override
	public String toString()
	{
		return name()+" Cost "+additionalCost;
	}
	

}
