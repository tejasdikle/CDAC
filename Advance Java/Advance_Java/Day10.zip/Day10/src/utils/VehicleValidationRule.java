package utils;

public enum VehicleValidationRule {

}
