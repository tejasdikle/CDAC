package utils;
import utils.VehicleValidationRule;
import static utils.VehicleValidationRule.validateAllInput;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.Vehicle.Vehicle;

public class Tester 
{	

	public static void main(String[] args) 
	{
		List<Vehicle> vehiclelists = new ArrayList<>();
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("----------------------------------");
			System.out.println("Welcome to the Vehicle Showroom ");
			System.out.println("----------------------------------");
			boolean exit = false;
			while(!exit)
			{
				System.out.println("Option \n1.Add Vehicle \n2.Display all vehicle");
				System.out.println("----------------------------------");
				switch(sc.nextInt ())
				{
				case 1:
				{	System.out.println("--------------------------------------------------------------------------------------------");
					System.out.println("Vehicle details :Enter  Chassi_no ,Vehicle_color,Company ,Manufacturing_Date ,Basic_Price ");
					System.out.println("--------------------------------------------------------------------------------------------");
					Vehicle validatvehicle = validateAllInput(sc.next(),sc.next(),sc.next(),sc.next(),sc.nextInt());
					vehiclelists.add(validatvehicle);
				}
				}
		
			}
		}

	}

	

}
