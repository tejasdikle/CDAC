package date_handling;

import java.time.LocalDate;
import java.util.Scanner;

public class TestLocalDate 
{

	public static void main(String[] args) 
	{
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("Todays date :");
			LocalDate today = LocalDate.now();
			System.out.println(today);
			System.out.println("Enter today date:");
			LocalDate date1 = LocalDate.parse(sc.next());
			System.out.println(date1);
			System.out.println(today.isAfter(date1));
			System.out.println(date1.isBefore(today));
			System.out.println(today.compareTo(date1));
		}
	}

}
