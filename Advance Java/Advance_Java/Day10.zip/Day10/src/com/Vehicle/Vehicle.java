package com.Vehicle;

import java.time.LocalDate;

public class Vehicle 
{
	private String chassino;
	private String vehiclecolor;
	private int basicprice;
	private String company;
	private boolean available;
	private LocalDate manufacturingDate;
	
	
	public Vehicle(String chassino, String vehiclecolor, int basicprice, String company, boolean available,
			LocalDate manufacturingDate) 
	{
		super();
		this.chassino = chassino;
		this.vehiclecolor = vehiclecolor;
		this.basicprice = basicprice;
		this.company = company;
		this.available = available;
		this.manufacturingDate = manufacturingDate;
	}


	

	public Vehicle(String chassino) 
	{
		super();
		this.chassino = chassino;
	}




	public String getChassino() {
		return chassino;
	}


	public void setChassino(String chassino) {
		this.chassino = chassino;
	}


	public int getBasicprice() {
		return basicprice;
	}


	public void setBasicprice(int basicprice) {
		this.basicprice = basicprice;
	}


	public LocalDate getManufacturingDate() {
		return manufacturingDate;
	}


	public void setManufacturingDate(LocalDate manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}


	@Override
	public String toString() {
		return "Vehicle [chassino=" + chassino + ", vehiclecolor=" + vehiclecolor + ", basicprice=" + basicprice
				+ ", company=" + company + ", available=" + available + "]";
	}
	
	
	
	
	
	

}
