package String_Handling;

public class Test1 {

	public static void main(String[] args) {
		
		String s = new String("hello");
		s.concat("hi");
		System.out.println(s);
		s+="1234";
		System.out.println(s);
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		String s1=
				s.replaceFirst("he", "zz");
		System.out.println(s1);
		
		

	}

}
