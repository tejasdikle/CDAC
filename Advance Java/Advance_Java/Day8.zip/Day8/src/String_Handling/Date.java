package String_Handling;
import java.util.Date.*;

public class Date 
{
	public static void main (String arg [])
	{
		Date d1 =new Date();
		System.out.println(d1);
		
		Date d2 = new Date();
		System.out.println(d2);
	}

}
