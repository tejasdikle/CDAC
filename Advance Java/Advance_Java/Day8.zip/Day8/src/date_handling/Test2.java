package date_handling;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;
public class Test2 
{
	private static SimpleDateFormat sdf;
	static 
	{
		System.out.println("I am in static block ");
		sdf = new SimpleDateFormat("dd-mm-yyyy");
	}
	public static void main(String []args)
	{
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("Enter first date here  ");
			Date d1 = sdf.parse(sc.next());
			System.out.println("Enter second date here  ");
			Date d2 = sdf.parse(sc.next());
			System.out.println(d1);
			System.out.println(d2);
			
			System.out.println(d1.equals(d2));
			
		}catch(Exception e )
		{
			System.out.println(e);
		}
		
	}
	
}
