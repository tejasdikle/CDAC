package date_handling;

public class Test4 
{
	public static void main(String[] args)
	{
	
	String s = "Tejas dhikale";
	System.out.println(s.contentEquals(s));
	System.out.println(s.lastIndexOf(9));
	}
}

