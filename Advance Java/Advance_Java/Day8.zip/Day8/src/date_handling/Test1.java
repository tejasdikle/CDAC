package date_handling;

import java.util.Date;

public class Test1 
{

	public static void main(String[] args) 
	{
		Date d1 = new Date();  // use this option we get current date
		System.out.println(d1);
		
		Date d2 = new Date(20000); 
		System.out.println(d2);
		
		
		System.out.println("------------");
		System.out.println(d1.before(d2));
		System.out.println("------------");
		System.out.println(d2.before(d1));
		System.out.println("------------");
		System.out.println(d1.equals(d2));
		System.out.println("------------");
		System.out.println("msec "+d1.getTime());
		System.out.println(d1.compareTo(d2));
		
		
		
	}

}
