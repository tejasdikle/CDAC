package date_handling;

public class Test3 
{

	public static void main(String[] args) 
	{
		try
		{
	
			String s= new String("hello tejas");
			System.out.println(s);
			
			System.out.println(s.toUpperCase());
			String s1 =s.replace("tejas ", "rahul");
			System.out.println(s1);
	
			System.out.println(s.length());
			System.out.println(s.charAt(0));
			
		
		
	    }
		catch (Exception e)
		{
	    	System.out.println("Error "); 
		}
	}

}
